import wikipedia

print(wikipedia.summary("Mercury"))