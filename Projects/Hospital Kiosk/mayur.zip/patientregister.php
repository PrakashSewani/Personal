<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="patientregister.css">
</head>
<body>
    <div class="topnav">
        <div class="Hname">
          <a class="navbar-brand"><img src="fortis.png" width="25" height="25" alt=""></a>
          <a href="index.html">Fortis Hospital</a>
        </div>
        <a class="active" href="admin.html">Admin</a>
        <a href="about.html">About</a>
        <a href="contact.html">Contact</a>
        <a href="#staff">Staff</a>
        <a href="index.html">Home</a>
        </div>
        <div class="bill">
            <img src="fortis.png" style="height: 70px;width: 70px;padding-left: 100px;">
            <h2 style="color: green;text-align: center;">Fortis</h2>
            <h2 style="color: black;font-size: 15px;">Enter your Name</h2>
            <input class="password" type="text" id="admin" name="admin"> 
            <h2 style="color: black;font-size: 15px;">Enter your password</h2>
            <input class="password" type="password" id="password" name="password"> 
            <h2 style="color: black;font-size: 15px;">Confirm your password</h2>
            <input class="password" type="password" id="password" name="password">
            <div class="submit">
                <button class="button">Submit</button>
            </div>
            <br>
            <br>
        </div>
</body>
</html>